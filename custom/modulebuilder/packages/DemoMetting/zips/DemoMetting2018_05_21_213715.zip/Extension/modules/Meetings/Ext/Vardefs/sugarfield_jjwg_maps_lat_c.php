<?php
 // created: 2018-05-14 17:48:25
$dictionary['Meeting']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 ?>